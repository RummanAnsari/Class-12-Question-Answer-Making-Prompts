=====================================================================
 WBCHSE Class XII - Modern Computer Application (COMA)
 Question Papers & Answer Keys  (70 Marks each)
=====================================================================

FOLDER STRUCTURE
-----------------------------------------------------------------
Unit1-DBMS/                          -> Database Management System
   DBMS_Question_Bangla.tex          (Questions only)
   DBMS_Question+Answer_Bangla.tex   (Questions + Explained Answers)

Unit2-DataWarehousing-DataMining/    -> Data Warehousing & Data Mining
   DWDM_Question_Bangla.tex
   DWDM_Question+Answer_Bangla.tex
   DWDM_Question_English.tex
   DWDM_Question+Answer_English.tex

Unit-Foundation-of-AI/               -> Foundation of AI
   AI_Question_Bangla.tex
   AI_Question+Answer_Bangla.tex
   AI_Question_English.tex
   AI_Question+Answer_English.tex

FILE NAMING
-----------------------------------------------------------------
   "Question"          = Question paper only
   "Question+Answer"   = Questions WITH detailed explanations

=====================================================================
 HOW TO COMPILE  (use Overleaf.com - easiest)
=====================================================================

 >>> BANGLA files:
     Compiler = XeLaTeX          Font = Kalpurush
     (Overleaf: Menu -> Settings -> Compiler -> XeLaTeX -> Recompile)

 >>> ENGLISH files:
     Compiler = pdfLaTeX
     (Overleaf: Menu -> Settings -> Compiler -> pdfLaTeX -> Recompile)

 IMPORTANT: Do NOT mix engines. Bangla = XeLaTeX, English = pdfLaTeX.

=====================================================================
 STRUCTURE OF EVERY PAPER  (WBCHSE 70-mark pattern)
=====================================================================
   Group A : 21 MCQ  x 1 = 21
   Group B : 14 Short x 1 = 14
   Group C : 7 Broad, answer any 5 x 7 = 35
   -----------------------------------------
   TOTAL                     = 70 marks
=====================================================================
